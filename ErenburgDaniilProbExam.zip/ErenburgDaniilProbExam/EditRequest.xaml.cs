﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ErenburgDaniilProbExam
{
    /// <summary>
    /// Логика взаимодействия для EditRequest.xaml
    /// </summary>
    public partial class EditRequest : Page
    {
        
        DatabaseAllRequest DB = new DatabaseAllRequest();
        public EditRequest()
        {
            InitializeComponent();
            CBListReq.ItemsSource = DB.GetIdRequest();
            CBWork.ItemsSource = DB.GetIdWorker();
        }

        private void GoUserMenu(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new UserMenu());
        }

        private void Changed(object sender, SelectionChangedEventArgs e)
        {
            TEXTBLOCK.Text = DB.GetDescription(CBListReq.SelectedValue.ToString());
            string name = DB.GetDeviceName(int.Parse(CBListReq.SelectedItem.ToString()));
            int DeviceId = DB.GetDeviceID(name);
            CBRemont.ItemsSource = DB.GetBreakdownsByDeviceId(DeviceId);
        }

        private void NewPage(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new EditRequest());
        }

        private void SaveBut(object sender, RoutedEventArgs e)
        {
            RadioButton[] radioButtons = { RBWaiting, RBWork, RBNotDone, RBDone };

            foreach (RadioButton radioButton in radioButtons)
            {
                if (radioButton.IsChecked == true)
                {
                    string selectedValue = radioButton.Content.ToString();
                }
            }


        }
    }
}

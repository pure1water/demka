﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ErenburgDaniilProbExam
{
    /// <summary>
    /// Логика взаимодействия для UserMenu.xaml
    /// </summary>
    public partial class UserMenu : Page
    {
        public UserMenu()
        {
            InitializeComponent();
        }

        private void GoAddReq(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddRequest());
        }

        private void GoEditReq(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new EditRequest());
        }

        private void GoAllReq(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AllRequest());
        }

        private void ExitAuto(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Authorization());
        }

        private void GoAddRating(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddRating());
        }
    }
}
